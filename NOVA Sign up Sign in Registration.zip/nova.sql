-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2024 at 02:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nova`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `reset_token_hash` varchar(64) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password_hash`, `reset_token_hash`, `reset_token_expires_at`) VALUES
(1, 'Gio', 'Giojoestar@gmail.com', '$2y$10$JAEYDhWj1RY8Ffdlx/ENU.fJ6zlzIr/THESgbXVYFuQRA6CTcct7y', NULL, NULL),
(2, 'Mary', 'Marymadington@gmail.com', '$2y$10$PFRxj1WnF22noFyB3iPlz.o1qzU6jSz/LEjNZcA4s4GFZz5om0hiO', NULL, NULL),
(5, 'David', 'Davidsterling@gmail.com', '$2y$10$hex5n7O20uulxY/zaNBsdOve0WGtggVwX99uHBjQWhQK.89VsGITS', NULL, NULL),
(8, 'Zio', 'ZionPemberton@gmail.com', '$2y$10$rn6ANaoC.yzD1ETnrFFSducBxTvJTKmcEnB1Vpo5pMraDsJfDjN4.', NULL, NULL),
(9, 'Tom', 'TomFletcher@gmail.com', '$2y$10$tJkfOll/XWA4cUpVqckroOKdfny4GE/4FN0cD7ujCC.9h.rsexktO', NULL, NULL),
(10, 'Joe', 'JoeGold@gmail.com', '$2y$10$AP/WhC82mji6i8dy/DHFE.ZQjkgRCDY7rC5qzwLX6nI/F7sUTdYRO', '335cf697b1f1dc8fd48b8bfdd073c11488deb4f3e53a6ba8781fdff5f2373a72', '2024-03-16 02:35:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `reset_token_hash` (`reset_token_hash`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
